const virtex2 = (pushname, prefix, botName, ownerName, getLevelingLevel, sender, _registered, uangku) => {
	return `GAK ADA PIRTEX SUBS RAFA YTG DULU DONG NGAB☹️`

}

exports.virtex2 = virtex2
