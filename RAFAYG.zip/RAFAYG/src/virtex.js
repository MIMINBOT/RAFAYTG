const virtex = (pushname, prefix, botName, ownerName, getLevelingLevel, sender, _registered, uangku) => {
	return Eee gak ada pirtex SUBSCRIBE RAFA YTG DULU DONG NGAB
}

exports.virtex = virtex
