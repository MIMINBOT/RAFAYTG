exports.wait = () => {
	return`*「❗」TUNGU SEBENTAR*`
}

exports.succes = () => {
	return`*「 SUKSES 」*`
}

exports.lvlon = () => {
	return`*「❗」LEVELING AKTIF*`
}

exports.lvloff = () => {
	return`*「❗」LEVELING NONAKTIF*`
}

exports.lvlnul = () => {
	return`*「❗」LEVELMU MASIH KOSONG [ NAIKIN LEVEL DENGAN CARA GUNAIN BOT TERUS MENERUS ]*`
}

exports.lvlnoon = () => {
	return`*「❗」LEVEL DI GRUB BELUM DI AKTIFKAN*`
}

exports.noregis = () => {
	return`*「❗」BELUM DAFTAR*\n*cara daftar ${prefix}daftar nama|umur* \n\n*contoh ${prefix}daftar RAFA YTG|20*`
}

exports.baned = () => {
	return`*「❗」MAAF KAMU TELAH DI BANNED UNTUK MEMBUKA BAN CHAT OWNER*`
}

exports.rediregis = () => {
	return`*「 SUDAH DAFTAR 」*\n\n*KAMU TELAH TERDAFTAR JANGAN LUPA SUBSCRIBE RAFA YTG*`
}

exports.stikga = () => {
	return`*「 GAGAL 」MOHON MAAF MOHON TUNNGU BERAPA DEKTIK*`
}

exports.linkga = () => {
	return`*「❗」MAAF LINK YANG ANDA KIRIM TIDAK VAILID*`
}

exports.groupo = () => {
	return`*「❗」HANYA BISA DI GUNAKAN DI GROUP*`
}

exports.ownerb = () => {
	return`*「❗」HANYA BISA DI GUNAKAN OLEH OWNER*`
}

exports.ownerg = () => {
	return`*「❗」HANYA BISA DI GUNAKAN OLEH OWNER*`
}

exports.admin = () => {
	return`*「❗」HANYA BISA DI GUNAKAN OLEH ADMIN*`
}

exports.badmin = () => {
	return`*「❗」BOT HARUS JADI ADMIN*`
}

exports.nsfwoff = () => {
	return`*「❗」NSFW GAK AKTIF*`
}

exports.bug = () => {
	return`*MASALAH TELAH DI LAPORKAN [ MASALAH MAIN MAIN KEMUNGKINAN KAMU BISA KE BAN☹️ ]*`
}

exports.wrongf = () => {
	return`*「🤔」Teks nya mana kak?*`
}

exports.clears = () => {
	return`*「🚮」Clear all Success*`
}

exports.pc = () => {
	return`*「❗」REGISTRASI*\n\nuntuk mengetahui apa kamu sudah terdaftar silahkah check message yang saya kirim \n\nNOTE:\n*jika kamu belum mendapatkan pesan. berarti kamu belum menyimpan nomer bot*`
}

exports.registered = (namaUser, umurUser, serialUser, time, sender, botName) => {
	return`*「 REGISTRASI BERHASIL 」*\nUntuk User Info :\n\n*➸ Nama : ${namaUser}*\n*➸ Nomor : wa.me/${sender.split("@")[0]}*\n*➸ Umur : ${umurUser}*\n*➸ Waktu Pendaftaran : ${time}*\n\n*「SN」: ${serialUser}*\n_NOTE : Pesan ini sangat penting :v_`
}

exports.cmdnf = (prefix, command) => {
	return`command *${prefix}${command}* tidak di temukan\coba tulis *${prefix}menu*`
}

exports.owneresce = (pushname) => {
	return`*maaf tapi ${pushname} bukan owner script*`
}
exports.levelup = (pushname, sender, getLevelingXp,  getLevel, getLevelingLevel) => {
	return`
*「 SELAMAT 」*
➸ *Nama* : ${pushname}
➸ *Nomor* : wa.me/${sender.split("@")[0]}
➸ *Xp* : ${getLevelingXp(sender)}
➸ *Level* : ${getLevel} ➸ ${getLevelingLevel(sender)}
`}
 
exports.limitend = (pushname) => {
	return`*maaf ${pushname} limit hari ini habis*\n*limit di reset setiap jam 24:00*`
}

exports.limitcount = (limitCounts) => {
	return`
*「 LIMIT COUNT 」*
sisa limit anda : ${limitCounts}

Upgrade premium bosku, biar bebas gunain bot`
}

exports.satukos = () => {
	return`*Tambah parameter 1/enable atau 0/disable`
}

exports.uangkau = (pushname, sender, uangkau) => {
	return`┏━━━━━━━♡ *ATM* ♡━━━━━━━┓\n┃╭───────────────────\n┃│➸ NAMA : ${pushname}\n┃│➸ NOMOR : ${sender.split("@")[0]}\n┃│➸ UANG : ${uangkau}\n┃╰───────────────────\n┗━━━━━━━━━━━━━━━━━━━━┛`
}